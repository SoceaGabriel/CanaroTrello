﻿namespace Canaro_Trello.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddmodelsinAppContext : DbMigration 
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
